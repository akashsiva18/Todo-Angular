import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TaskComponent } from './bottom-center/task.component';
import { TaskDetailsComponent } from './bottom-right/task-details.component';
import { CategoryListComponent } from './bottom-left/category-list/category-list.component';
import { CommonComponent } from './common-component.component';
import { TaskListComponent } from './bottom-center/task-list/task-list.component';
import { FormsModule } from '@angular/forms';
import { FilterTaskPipe } from '../filter-task.pipe';
import { CategoryComponent } from './bottom-left/category.component';

@NgModule({
  declarations: [
    TaskComponent,
    CategoryComponent,
    TaskDetailsComponent,
    CategoryListComponent,
    CommonComponent,
    TaskListComponent,
    FilterTaskPipe
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [
    TaskComponent,
    CategoryComponent,
    TaskDetailsComponent,
    CommonComponent
  ]
})
export class CommonComponentModule { }