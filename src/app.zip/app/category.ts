export interface Category {
  id:number;
  name:string;
  iconClass:string;
  count:number;
  isLastDefaultCategory:boolean;
  isDefaultCategory:boolean;

}