import { FilterTaskPipe } from './filter-task.pipe';

describe('FilterTaskPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterTaskPipe();
    expect(pipe).toBeTruthy();
  });
});
